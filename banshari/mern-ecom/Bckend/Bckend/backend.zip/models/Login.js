let mongoose = require('mongoose');

mongoose.Schema({
    email: String,
    userId: Number,
    // CurrentTime: 
})